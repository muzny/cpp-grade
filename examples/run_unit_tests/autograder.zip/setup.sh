#!/usr/bin/env bash

apt-get install -y build-essential
apt install -y gcc-8 g++-8
alias g++=g++-8
alias gcc=gcc-8